# Prompt 05 — Evaluate against the plan’s own criteria

Paste the whole of [CONTRACT.md](../CONTRACT.md) first, then the block under “Prompt” below, into a fresh session.

## Prerequisites

- [Prompt 04](04-carry-out-and-record.md) passed its completion gate.

## Scope

- Compare what happened with the Objectives and the Testing and evaluation criteria.
- Say what the evidence shows and what it does not.

## Expected artifacts

- An evaluation note: each criterion, what was observed, and whether it was met, not met or cannot be told.
- A recommendation to the owner: continue, change, or stop.

## Completion gate

- Every criterion in the plan has one of: met, not met, cannot tell (with the reason).
- The note states the result that would count as failure, and whether it happened.
- Someone who did not carry out the steps has read the note.

If the gate does not pass, follow [RECOVERY.md](../RECOVERY.md).

## Prompt

```text
Step: evaluate. Judge against the plan’s criteria, not new ones.

Objectives: UNKNOWN. State the outcome this should change, for whom, and how it will be measured.
Evaluation criteria: UNKNOWN. Say how success will be tested and what result would count as failure. The selection said it would reverse if: Reminders are already fully configured at every clinic.
The decision would be reversed if: Reminders are already fully configured at every clinic.

1. For each criterion write what was observed and who observed it.
2. Mark it met, not met, or cannot tell. "Cannot tell" is an honest answer.
3. Do not change a criterion after seeing the result. If one was badly chosen,
   say so separately.
4. A few people trying something once is not proof. Say how many, and how long.
5. Check the assumptions in DECISIONS.md: did any turn out wrong?
6. Recommend continue, change or stop, and ask a person who did not do the work
   to read the note.
```

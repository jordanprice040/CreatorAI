# Prompt 04 — Carry out the steps and keep the record

Paste the whole of [CONTRACT.md](../CONTRACT.md) first, then the block under “Prompt” below, into a fresh session.

## Prerequisites

- [Prompt 03](03-prepare.md) passed its completion gate.

## Scope

- People carry out the approved checklist. The assistant keeps the record and flags departures.

## Expected artifacts

- A log: each step, who did it, when, and what was observed.
- A list of departures from the plan and why.

## Completion gate

- Each checklist step is logged as done (by whom), skipped (why) or blocked (on what).
- Nothing is logged as done on the assistant’s own say-so.

If the gate does not pass, follow [RECOVERY.md](../RECOVERY.md).

## Prompt

```text
Step: carry out and record. People act; you keep the log.

1. For each checklist step, ask the person responsible what happened.
2. Log it: step, role, date, what was observed. Use their words.
3. If a step was changed or skipped, log why. Do not hide it.
4. If anything in the Ethics and risks section starts to happen, say so at once
   and follow RECOVERY.md.
5. Report the log and any blocked step.

Ethics and risks (one-line copy): UNKNOWN. Confirm the ethics, access and risk points. Trade-offs recorded with the option: - Feasibility: Evidence: C4. - Maintenance: Vendor-maintained; local configuration only.
```

# Prompt 01 — Understand the plan and list what is missing

Paste the whole of [CONTRACT.md](../CONTRACT.md) first, then the block under “Prompt” below, into a fresh session.

## Prerequisites

- None. This is the first step.

## Scope

- Read the bundle. Change and do nothing.

## Expected artifacts

- A one-page summary of the plan in plain words.
- A list of every unknown section and open decision, with who could settle each.

## Completion gate

- The owner confirms the summary matches what they mean.
- Every unknown section in PLAN.md appears in the list.

If the gate does not pass, follow [RECOVERY.md](../RECOVERY.md).

## Prompt

```text
Step: understand the plan. Do not act on it yet.

1. Read PLAN.md, DECISIONS.md and EVIDENCE.md.
2. Write a one-page summary: the problem, who it affects, what will be done, by
   whom, and how anyone will know it helped.
3. List every section marked UNKNOWN and every open decision. For each, say who
   could settle it and what you would need from them.
4. List the contrary evidence and what it would mean if it is right.
5. Report. Wait for the owner to confirm the summary.
```

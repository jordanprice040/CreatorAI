# Prompt 02 — Close the unknown sections with the owner

Paste the whole of [CONTRACT.md](../CONTRACT.md) first, then the block under “Prompt” below, into a fresh session.

## Prerequisites

- [Prompt 01](01-orient.md) passed its completion gate.

## Scope

- Only these sections: Objectives; Contrary evidence; Methods and step-by-step procedure; Materials and resources; Roles; Timeline; Cost estimates and unknowns; Testing and evaluation criteria; Ethics and risks; Next tasks.
- Draft questions and options. The owner supplies the answers.

## Expected artifacts

- For each unknown section: the question, the options, and the owner’s answer in their own words (or “still unknown”).

## Completion gate

- Each unknown section has an owner answer, or is explicitly left unknown with the reason.
- No answer was written by the assistant on the owner’s behalf.

If the gate does not pass, follow [RECOVERY.md](../RECOVERY.md).

## Prompt

```text
Step: close the unknown sections. You ask; the owner answers.

Unknown now:
  - Objectives: State the outcome this should change, for whom, and how it will be measured.
  - Contrary evidence: No contrary claim is linked to this problem; that does not show there is none.
  - Methods and step-by-step procedure: Describe the step-by-step procedure: who does what, in what order, with which tools.
  - Materials and resources: List the materials, tools, data and other resources needed.
  - Roles: Name the roles (not people’s private details) and what each is responsible for.
  - Timeline: Give the stages and their expected durations.
  - Cost estimates and unknowns: Estimate the costs; a cost nobody knows stays unknown, not zero.
  - Testing and evaluation criteria: Say how success will be tested and what result would count as failure. The selection said it would reverse if: Reminders are already fully configured at every clinic.
  - Ethics and risks: Confirm the ethics, access and risk points. Trade-offs recorded with the option: - Feasibility: Evidence: C4. - Maintenance: Vendor-maintained; local configuration only.
  - Next tasks: List the next concrete tasks.

1. For each one, write the plainest question that would settle it and two or
   three realistic options with what each would cost or risk.
2. Ask the owner. Record the answer in their words.
3. If the owner does not know, record "still unknown" and what would find out.
4. Do not invent an answer, a cost, a date or a name.
5. Report the answers and what remains unknown.
```

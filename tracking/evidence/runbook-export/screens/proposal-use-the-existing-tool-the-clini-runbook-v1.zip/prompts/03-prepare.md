# Prompt 03 — Prepare materials, roles and schedule

Paste the whole of [CONTRACT.md](../CONTRACT.md) first, then the block under “Prompt” below, into a fresh session.

## Prerequisites

- [Prompt 01](01-orient.md) passed its completion gate.
- [Prompt 02](02-close-the-unknowns.md) passed its completion gate.

## Scope

- Turn the Methods, Materials, Roles and Timeline sections into a checklist people can follow.
- Prepare drafts only. Send nothing and buy nothing.

## Expected artifacts

- A step-by-step checklist with an owner for each step (roles, not private details).
- A list of materials with what is in hand and what is missing.
- A schedule with the stages from the Timeline section.

## Completion gate

- Every step in the Methods section appears in the checklist, in order.
- The owner approves the checklist and schedule.

If the gate does not pass, follow [RECOVERY.md](../RECOVERY.md).

## Prompt

```text
Step: prepare. Draft only; a person sends, buys and books.

Methods: UNKNOWN. Describe the step-by-step procedure: who does what, in what order, with which tools.
Materials: UNKNOWN. List the materials, tools, data and other resources needed.
Roles: UNKNOWN. Name the roles (not people’s private details) and what each is responsible for.
Timeline: UNKNOWN. Give the stages and their expected durations.
Costs: UNKNOWN. Estimate the costs; a cost nobody knows stays unknown, not zero.

(These are one-line copies. PLAN.md has the full text and is the authority.)

1. Write the procedure as a numbered checklist. Each step: who does it (a role),
   what they need, how they know it is done.
2. List the materials: in hand, missing, and who gets each missing one.
3. Lay the steps on the timeline. Mark any date that is a guess.
4. A cost nobody knows stays "unknown". Do not write zero.
5. Ask the owner to approve the checklist and schedule.
```

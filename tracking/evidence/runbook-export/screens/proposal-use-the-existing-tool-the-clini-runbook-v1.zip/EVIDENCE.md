# Evidence

These are the claims recorded for the problem, with the sources that back or dispute them. They were copied from the studio when this bundle was made. A claim is what the records say, not a proven fact; check a source yourself before relying on it. Quotes are short excerpts; the full sources are not in this bundle.

## Supporting

- **[R1]** Rural clinics recorded a 23 percent no-show rate for first appointments in 2025. (claim 42174253, version 1; evidence status: supported)
  - Missed first appointments at rural clinics, 2025: <https://health.fixture.test/reports/no-shows-2025> (supports, current) — “recorded a 23 percent no-show rate for first appointments in 2025”

## Contrary

None recorded.

No contrary claim is recorded. That does not show there is none.

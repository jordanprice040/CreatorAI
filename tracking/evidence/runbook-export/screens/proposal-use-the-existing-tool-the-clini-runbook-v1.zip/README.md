# Proposal: Use the existing tool: The clinics’ scheduling systems send reminders but do not predict no-shows. — action runbook

This folder is a self-contained handover for carrying out a plan that is **not** a software build. People do the work. An assistant can help prepare, keep the record and check, using the prompts below.

_This is a plan. It has not been carried out, and nothing here shows that it works in practice._

> An existing tool for “Unused first-appointment slots at rural clinics: Rural clinics recorded a 23 percent no-show rate for first appointments in 2025.”: Use the existing tool: The clinics’ scheduling systems send reminders but do not predict no-shows.

## Read this first

- 10 sections of the plan are still unknown: Objectives; Contrary evidence; Methods and step-by-step procedure; Materials and resources; Roles; Timeline; Cost estimates and unknowns; Testing and evaluation criteria; Ethics and risks; Next tasks.
- The plan has 5 open blockers (listed at the end of PLAN.md).

## How to use it

1. Read [PLAN.md](PLAN.md) and [DECISIONS.md](DECISIONS.md).
2. For each prompt below, in order: paste [CONTRACT.md](CONTRACT.md), then the prompt. A person can also follow the prompts directly.
3. Do not start a prompt until the ones it depends on have passed their completion gate.
4. When a step fails, follow [RECOVERY.md](RECOVERY.md).

## Prompts, in order

| # | Prompt | Needs |
| --- | --- | --- |
| 01 | [Understand the plan and list what is missing](prompts/01-orient.md) | nothing |
| 02 | [Close the unknown sections with the owner](prompts/02-close-the-unknowns.md) | 01 |
| 03 | [Prepare materials, roles and schedule](prompts/03-prepare.md) | 01, 02 |
| 04 | [Carry out the steps and keep the record](prompts/04-carry-out-and-record.md) | 03 |
| 05 | [Evaluate against the plan’s own criteria](prompts/05-evaluate-and-review.md) | 04 |

## Files

- [CONTRACT.md](CONTRACT.md): the shared contract, pasted before every prompt.
- [PLAN.md](PLAN.md): the plan, exactly as saved.
- [DECISIONS.md](DECISIONS.md): decided, assumed and still open.
- [EVIDENCE.md](EVIDENCE.md): the claims and sources the plan cites.
- [RECOVERY.md](RECOVERY.md): what to do when a step fails.
- [manifest.json](manifest.json): versions and a SHA-256 hash of every file. To check the bundle with any tool: each listed file’s SHA-256 must equal its `sha256`, and `bundle_hash` is the SHA-256 of one line per listed file, in the listed order, made of the path, one space, the file’s hash and a line feed.

## How to check the work

There is nothing to run. Each prompt ends with a completion gate that a person confirms. The last prompt compares what happened with the plan’s own evaluation criteria.

## What is deliberately not here

- Reviews of the plan, scores, chat and other studio records the plan does not cite.
- Credentials, accounts and access of any kind.
- Personal folder paths and anything shaped like a credential (removed if found).

## Where it came from

- Proposal 2f18743f-3fd8-4732-891d-fd4016cc2519, version 1, content hash `ec8e9e4a7a88cb6098ef65a7d368be4de16266051aea3c0b74cf048bf2e8456f`, saved 2026-11-10T08:44:48.709Z
- Selection a07ef051-488d-40b3-88cd-6eec89e13942
- Option 166cfd34-c6c8-40c9-a1d2-3560db32ec17, version 1
- Problem ac23d35c-9ed4-4dc1-884a-47e231be7def, version 1
- Produced by Creator Agent’s runbook export (`runbook/1`) from recorded data; no model wrote these files.

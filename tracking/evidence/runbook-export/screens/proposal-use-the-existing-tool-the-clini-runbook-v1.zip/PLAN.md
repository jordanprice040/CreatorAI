# Proposal: Use the existing tool: The clinics’ scheduling systems send reminders but do not predict no-shows.

> An existing tool for “Unused first-appointment slots at rural clinics: Rural clinics recorded a 23 percent no-show rate for first appointments in 2025.”: Use the existing tool: The clinics’ scheduling systems send reminders but do not predict no-shows.

- Problem: Unused first-appointment slots at rural clinics: Rural clinics recorded a 23 percent no-show rate for first appointments in 2025. (v1)
- Response: an existing tool — Use the existing tool: The clinics’ scheduling systems send reminders but do not predict no-shows. (v1)
- Proposal eec9b7fa-41fe-446b-bdfa-cf1bc7536614, version 1, content hash 55925626225c1ab8766200fa4416624d267804f05dd43227ca422ec7212b0dfc
- Version saved 2026-11-10T08:44:25.507Z
- Document checks: core sections still unknown; 5 blocker(s), 5 warning(s)
- Reviews are kept in the studio with the version they judged; they are not part of this file.
- Section text is shown exactly as written, in a text block.

_This is a plan. It has not been carried out, and nothing here shows that it works in practice._

## Problem and who it affects

```proposal-text
First-appointment slots go unused when booked patients do not attend, while others wait. Evidence: Rural clinics recorded a 23 percent no-show rate for first appointments in 2025. (C1, supported)

Affected group: Front-desk staff and clinic managers at rural clinics
```

## Background

```proposal-text
Selected response: an existing tool — Use the existing tool: The clinics’ scheduling systems send reminders but do not predict no-shows.

Adopt what already exists: The clinics’ scheduling systems send reminders but do not predict no-shows. Software warranted: no. An existing tool exists (C4), but a gap is reported (C4).

Why it was selected:
- Highest suitability; turn on reminders now regardless of the build.

Selection rationale: Build the tool; turn on reminders meanwhile (walk).
```

## Objectives

**Unknown.**

```proposal-text
State the outcome this should change, for whom, and how it will be measured.
```

## Evidence

```proposal-text
1 supporting claim is cited here; their statements, sources and current evidence status are listed under References.
```

Cited: [R1]

## Contrary evidence

**Unknown.**

```proposal-text
No contrary claim is linked to this problem; that does not show there is none.
```

## Methods and step-by-step procedure

**Unknown.**

```proposal-text
Describe the step-by-step procedure: who does what, in what order, with which tools.
```

## Materials and resources

**Unknown.**

```proposal-text
List the materials, tools, data and other resources needed.
```

## Roles

**Unknown.**

```proposal-text
Name the roles (not people’s private details) and what each is responsible for.
```

## Timeline

**Unknown.**

```proposal-text
Give the stages and their expected durations.
```

## Cost estimates and unknowns

**Unknown.**

```proposal-text
Estimate the costs; a cost nobody knows stays unknown, not zero.
```

## Testing and evaluation criteria

**Unknown.**

```proposal-text
Say how success will be tested and what result would count as failure.

The selection said it would reverse if: Reminders are already fully configured at every clinic.
```

## Ethics and risks

**Unknown.**

```proposal-text
Confirm the ethics, access and risk points.

Trade-offs recorded with the option:
- Feasibility: Evidence: C4.
- Maintenance: Vendor-maintained; local configuration only.
```

## Limitations

```proposal-text
Discovery run f33d0d3b-0d64-4b02-9058-1d337308b96b (fixture): locator rated the evidence well supported; packet sufficient. Evidence for urgency or frequency is contested.

Disposition: candidate.
```

## Decision-changing assumptions

```proposal-text
- The selection would be reversed if: Reminders are already fully configured at every clinic.
- “Hybrid: routine workaround supported by a simple list from existing data” would become preferable if: Evidence that raises Feasibility/resource burden from 3.0 to above 5.0 (a 5 means: Available resources and a proportionate, well-supported path).
- “Hybrid: routine workaround supported by a simple list from existing data” would become preferable if: Evidence that raises Maintenance burden from 3.0 to above 4.0 (a 5 means: Low/proportionate obligations with an explicit sustainable owner/process).
- “Hybrid: routine workaround supported by a simple list from existing data” would become preferable if: A rating for Evidence support, which is unknown now (unknown is not a neutral score).
```

## Next tasks

**Unknown.**

```proposal-text
List the next concrete tasks.
```

## References

- [R1] Rural clinics recorded a 23 percent no-show rate for first appointments in 2025. — claim 42174253, cited at v1; supports; evidence supported
  - Missed first appointments at rural clinics, 2025: <https://health.fixture.test/reports/no-shows-2025> (supports, current) — “recorded a 23 percent no-show rate for first appointments in 2025”

## Open checks

- Blocker: Objectives is marked unknown.
- Blocker: Methods and step-by-step procedure is marked unknown.
- Blocker: Testing and evaluation criteria is marked unknown.
- Blocker: Ethics and risks is marked unknown.
- Blocker: Next tasks is marked unknown.
- Warning: Contrary evidence is marked unknown.
- Warning: Materials and resources is marked unknown.
- Warning: Roles is marked unknown.
- Warning: Timeline is marked unknown.
- Warning: Cost estimates and unknowns is marked unknown.

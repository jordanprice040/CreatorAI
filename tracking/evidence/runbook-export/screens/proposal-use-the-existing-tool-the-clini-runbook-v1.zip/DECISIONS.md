# Decisions and assumptions

## Decided and recorded

- **Selection** (2026-11-10, id d71d9fac): “Use the existing tool: The clinics’ scheduling systems send reminders but do not predict no-shows.” (an existing tool) was recommended instead of building software.
  - Reason: Highest suitability; turn on reminders now regardless of the build.
  - Rationale: Build the tool; turn on reminders meanwhile (walk).
  - It would be reversed if: Reminders are already fully configured at every clinic.

## Written in the plan (a proposal, not a decision)

Everything in PLAN.md is what its authors propose. Reviews of the plan stay in the studio and are not part of this bundle, so this bundle does not show the plan was approved.

## Assumptions that would change the plan

- The selection would be reversed if: Reminders are already fully configured at every clinic.
- Uncertainty recorded with the option: Disposition: candidate.
- Trade-off recorded with the option: Feasibility: Evidence: C4.
- Trade-off recorded with the option: Maintenance: Vendor-maintained; local configuration only.

See also the “Decision-changing assumptions” section of [PLAN.md](PLAN.md).

## Still to decide (by the owner)

- Objectives is unknown.
- Contrary evidence is unknown.
- Methods and step-by-step procedure is unknown.
- Materials and resources is unknown.
- Roles is unknown.
- Timeline is unknown.
- Cost estimates and unknowns is unknown.
- Testing and evaluation criteria is unknown.
- Ethics and risks is unknown.
- Next tasks is unknown.
- Who is accountable for carrying the plan out, and when it starts.
- Any spending, outside contact or use of personal data: each needs the owner’s own decision.

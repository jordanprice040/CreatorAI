# When something fails

Use this whenever a gate does not pass, a step cannot be finished, or the bundle and reality disagree.

1. **Stop at the failing step.** Do not start a later prompt; its prerequisites are not met.
2. **Write down what happened**: the step, who did it, what was expected and what was seen.
3. **Do not improvise a different plan.** If a step cannot be done as written, ask the owner which change to make.
4. **Repeat the step only when the cause is understood**, and note that it was repeated.
5. **After two failed tries, stop** and report to the owner.
6. **Never change a requirement, an acceptance check or its expected output to get a pass.** They are fixed in this bundle. If one looks wrong, say so in your report and leave it as it is.
7. **If the bundle is missing something you need** (a decision, data, an account, a credential), do not invent it. List it as a blocker. Nothing in this bundle grants access to anything.
8. **If something could harm a person or their data**, stop the step first and report second.

A report of a failure is a good result. A pass that was not observed is not.

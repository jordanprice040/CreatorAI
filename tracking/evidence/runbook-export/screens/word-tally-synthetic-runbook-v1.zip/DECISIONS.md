# Decisions and assumptions

This file separates what people recorded as decided from what this bundle only proposes.

## Decided and recorded

- **Selection** (2026-11-10, id a07ef051): “Software: Airline overbooking calculations from historical no-show rates have been used to double-book outpatient slots with a high predicted no-show probability.” (custom software) was selected for a build.
  - Reason: Gates pass and a two-week manual baseline exists to compare against.
  - Rationale: Build the tool; turn on reminders meanwhile (walk).
  - It would be reversed if: The manual flagging pilot shows no fewer unused slots.
- **Requirements frozen** on 2026-11-10 at spec version 1 (freeze 1c2b33c4).
- **No should-this-be-software review** of this spec is recorded. Whether this should be software at all has not been reviewed.

## Proposed by this bundle (not decided)

- The stack in STACK.md (Python command-line program (standard library only)).
- The order of tasks that do not depend on each other (TASKS.md keeps the spec’s order).
- The split into one prompt per task, and the wording of the prompts.

## Assumptions that would change the plan

- The selection would be reversed if: The manual flagging pilot shows no fewer unused slots.
- Uncertainty recorded with the option: Disposition: candidate.  Dissent: Pass 1, counterevidence: C2 is contested: Rural first-appointment waits rose between 2022 and 2025. \| Pass 1, cheaper test: Run the flagging by hand from an export for two weeks before building anything. \| Pass 2, counterevidence: C2 is contested: Rural first-appointment waits rose between 2022 and 2025. \| Pass 2, cheaper test: Run the flagging by hand from an export for two weeks before building anything.
- Trade-off recorded with the option: Feasibility: Data: Clinic scheduling systems export appointment histories with attendance.
- Trade-off recorded with the option: Maintenance: Needs an owner to keep data imports current and to retire it if unused.
- Trade-off recorded with the option: Assumes: Staff will act on what the tool flags.
- Trade-off recorded with the option: Assumes: Passes the cheaper test first: Run the flagging by hand from an export for two weeks before building anything.

## Still to decide (by the owner)

- Carry out the should-this-be-software (humility) review of this spec version, or confirm the work should go ahead without one.
- Name who judges the checks that have no executable case here (A3) and how.
- Run the 2 held-out cases on the finished work; only the owner has them.
- Where and how the result is released, hosted, published or sold. Nothing here decides that.
- The licence for the code, and who may see the repository.

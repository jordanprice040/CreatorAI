import json
import sys
ITEMS = ["inspect", "build", "review", "verify"]
if sys.argv[1:] == ["--plain"]:
    print("\n".join(ITEMS))
    sys.exit(0)
if len(sys.argv) > 1:
    print("invalid input")
    sys.exit(2)
print(json.dumps({"template": "checklist/1", "items": ITEMS}))

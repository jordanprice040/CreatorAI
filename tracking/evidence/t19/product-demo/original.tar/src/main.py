import json
import sys
if len(sys.argv) > 1:
    print("invalid input")
    sys.exit(2)
print(json.dumps({"template": "checklist/1", "items": ["inspect", "build", "review", "verify"]}))

# Reviewed Python template
Synthetic local checklist. No dependencies or network.

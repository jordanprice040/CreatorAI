import { SearchBriefBodySchema } from './discovery.js';
import {
  z,
  id,
  text,
  hash,
  counter,
  nanoUsd,
  ConditionSchema,
  DiscoverySchema,
} from './primitives.js';

const frozenText = z.strictObject({ version: text, text });
const ref = z.strictObject({ id, version: counter.min(1) });
/**
 * An implementation task frozen in the owner's workspace. Every hash is checked against the
 * stored spec, its freeze and its humility review before a study can bind it.
 */
export const StudyImplementationSchema = z.strictObject({
  spec_id: id,
  spec_version: counter.min(1),
  spec_hash: hash,
  freeze_id: id,
  task_key: z.string().regex(/^T[1-9][0-9]?$/),
  task_hash: hash,
  humility_review: ref,
  max_repairs: counter.max(2),
  timeout_ms: counter.min(100).max(60000),
  max_output_tokens: counter.min(100).max(16000),
});
/** A study-governance item is either explicitly unresolved or decided in the adopted freeze. */
export const GovernanceItemSchema = z.discriminatedUnion('status', [
  z.strictObject({ status: z.literal('unresolved'), decision: text }),
  z.strictObject({
    status: z.literal('decided'),
    decision: text,
    choice: text,
    reference: text,
  }),
]);
export const StudyGovernanceSchema = z.strictObject({
  label: text,
  participants: GovernanceItemSchema,
  reviewers: GovernanceItemSchema,
  human_subjects: GovernanceItemSchema,
  task_selection: GovernanceItemSchema,
  model: z.strictObject({
    owner_preference: text,
    verified_model_id: text.nullable(),
    decision: text,
  }),
  budget: z.strictObject({ ledger_cap_nano_usd: nanoUsd }),
});
export const StudyPacketSchema = z
  .strictObject({
    version: text,
    stratum: z.enum(['decision', 'implementation']),
    problem: text.max(1200),
    initial_resources: z
      .array(
        z.strictObject({ locator: text.max(1000), snapshot: text.max(2000) }),
      )
      .max(30),
    outcome: text.max(300),
    structured_brief: SearchBriefBodySchema,
    time_cap_seconds: counter.min(5).max(86400),
    implementation: StudyImplementationSchema.optional(),
  })
  .superRefine((p, ctx) => {
    if (p.implementation && p.stratum !== 'implementation')
      ctx.addIssue({
        code: 'custom',
        message: 'Only the implementation stratum binds a frozen build task.',
      });
    if (
      p.problem !== p.structured_brief.measurable_problem ||
      p.outcome !== p.structured_brief.outcome_measure
    )
      ctx.addIssue({
        code: 'custom',
        message:
          'The structured brief must use exactly the same problem and outcome as the shared packet.',
      });
  });
export const StudyConfigSchema = z.strictObject({
  model_version: text,
  pricing_version: text,
  tool_access: z.array(text).max(20),
  candidate_count: counter.min(2).max(5),
  max_calls: counter.min(7).max(60),
  max_output_tokens: counter.min(16).max(8000),
  max_cost_nano_usd: nanoUsd,
  max_retries: counter.max(2),
});
export const CreateStudySchema = z.strictObject({
  schema_version: z.literal('study/1'),
  /** false only for a final record bound to an adopted freeze; see the store's record gate. */
  synthetic: z.boolean(),
  title: text,
  protocol: frozenText,
  packet: StudyPacketSchema,
  config: StudyConfigSchema,
  rubric: frozenText,
  intervention_policy: frozenText,
  analysis_plan: frozenText,
  missing_data_policy: frozenText,
  stop_retry_rules: frozenText,
  primary_outcomes: z.array(text).min(1).max(10),
  assignment_seed: text,
  governance: StudyGovernanceSchema.optional(),
  evaluation: z.strictObject({ freeze_hash: hash }).optional(),
});
export const AssignStudySchema = z.strictObject({
  manifest_hash: hash,
  comparison: z.enum(['autonomy', 'discovery']).default('autonomy'),
  participant_actor_id: id,
  participant_code: text,
  prior_familiarity: text,
  condition: ConditionSchema,
  discovery_method: DiscoverySchema,
  continuation_of: id.nullable(),
});
export const StudyArtifactSchema = z.strictObject({
  kind: z.enum(['document', 'code', 'artifact']),
  name: text,
  content: z.string().max(24000),
});
export const StudyTestSchema = z.strictObject({
  artifact_id: id,
  artifact_hash: hash,
  check: z.enum(['contains', 'equals', 'json_valid']),
  expected: z.string().max(8000),
});
export const StudyInterventionSchema = z.strictObject({
  type: z.enum(['clarification', 'judgment', 'authorization', 'feedback']),
  gate: z.enum(['fixed', 'dynamic']),
  reason: text,
  trigger: text,
  stage: text,
  data_shown: text,
  human_input: text,
  resulting_change: text,
  prevented_problem: z.enum(['yes', 'no', 'unknown']),
  human_active_minutes: z.number().min(0).max(1440),
  wait_seconds: counter.max(86400),
});
export const FinishStudyAttemptSchema = z.strictObject({
  status: z.enum([
    'submitted',
    'failed',
    'cancelled',
    'needs_human',
    'budget_exhausted',
  ]),
  summary: text,
  human_active_minutes: z.number().min(0).max(1440),
  human_wait_seconds: counter.max(86400),
});
export const StudyAttemptSchema = z.strictObject({
  id,
  study_id: id,
  workspace_id: id,
  run_id: id,
  synthetic: z.boolean(),
  participant_actor_id: id,
  participant_code: text,
  prior_familiarity: text,
  condition: ConditionSchema,
  discovery_method: DiscoverySchema,
  comparison: z.enum(['autonomy', 'discovery']),
  order: counter.min(1),
  continuation_of: id.nullable(),
  primary: z.boolean(),
  manifest_hash: hash,
  context_hash: hash,
  state: z.enum([
    'assigned',
    'submitted',
    'failed',
    'cancelled',
    'needs_human',
    'budget_exhausted',
  ]),
  created_at: z.string(),
  finished_at: z.string().nullable(),
});
export const StudySummarySchema = z.strictObject({
  id,
  title: text,
  synthetic: z.boolean(),
  manifest_hash: hash,
  status: z.enum(['draft_not_frozen', 'final_record']),
  created_at: z.string(),
});
export type StudyInput = z.infer<typeof CreateStudySchema>;
export type StudyImplementation = z.infer<typeof StudyImplementationSchema>;
export type StudyGovernance = z.infer<typeof StudyGovernanceSchema>;
export type StudyAssignment = z.infer<typeof AssignStudySchema>;
export type StudyAttempt = z.infer<typeof StudyAttemptSchema>;
export type StudySummary = z.infer<typeof StudySummarySchema>;
